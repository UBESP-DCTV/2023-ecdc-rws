# Dev -------------------------------------------------------------
requireNamespace("devtools")
requireNamespace("webshot2")


# CRAN - BASE -----------------------------------------------------
requireNamespace("glue")
requireNamespace("gt")
requireNamespace("gtsummary")
requireNamespace("here")
requireNamespace("janitor")
requireNamespace("labelled")
requireNamespace("rio")
requireNamespace("skimr")
requireNamespace("tidyverse")
requireNamespace("unheadr")
requireNamespace("car")
